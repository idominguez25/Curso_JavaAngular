public class SueldoEmpleadoApp {		
	
	public static void main(String[] args) {
		
		ArchivoEmpleados.mostramosEmpleados();
		
	}
	
}