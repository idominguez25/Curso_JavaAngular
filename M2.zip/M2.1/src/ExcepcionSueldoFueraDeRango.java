public class ExcepcionSueldoFueraDeRango extends Exception {

	public ExcepcionSueldoFueraDeRango (String mensajeError) {
		super(mensajeError);
	}
	
}