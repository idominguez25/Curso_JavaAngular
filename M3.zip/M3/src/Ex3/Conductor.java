package Ex3;

public class Conductor extends Persona{
	//Constructor
	public Conductor(String nombre, String apellidos, String fechaNacimiento, String licencia, Licencia licencia1) {
		super(nombre, apellidos, fechaNacimiento, licencia, licencia1);
	}
}
