package Ex3;

public class Camion {

}
