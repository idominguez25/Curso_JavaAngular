package Ex4;

import java.util.Scanner;

import Excepcion.MiExcepcion;

public class Ex4App {

	public static void main(String[] args) {
		int num1;
		int num2;
		double resultado;
		String respuesta;
		Scanner teclado = new Scanner (System.in);
		
		try {
			System.out.println("Que operaci�n quieres hacer?");
			respuesta = teclado.next();
			switch (respuesta) {
			case "Sumar":
				num1 + num2;
			break;
			case "Restar":
				num1 - num2;
				if ()
			
			}
			
		}
		catch (MiExcepcion ex) {
			System.out.println(ex.getMessage());
		}

	}

}
