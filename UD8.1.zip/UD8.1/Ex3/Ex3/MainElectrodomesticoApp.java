package Ex3;

public class MainElectrodomesticoApp {

	public static void main(String[] args) {
		Electrodomestico nevera = new Electrodomestico (150, "Naranja", 'Z', 10);
		System.out.println(nevera.toString());

	}

}
