package Ex4;

public class MainSerieApp {

	public static void main(String[] args) {
		Serie serie1 = new Serie ();
		System.out.println(serie1.toString());

	}

}
