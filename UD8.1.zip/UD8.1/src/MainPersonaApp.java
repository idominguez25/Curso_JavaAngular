
public class MainPersonaApp {

	public static void main(String[] args) {
		//Creamos una persona con todos los datos y comprobamos que funciona.
		Persona persona1 = new Persona ("Ingrid", 18, "12345678X", 'M', 60, 1.69);
		System.out.println(persona1.toString());

	}

}
