package Ex2;

public interface Entregable {
	//M�todos
	public boolean entregar();
	boolean devolver();
	void isEntregado();

}
